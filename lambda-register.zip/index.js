'use strict';

const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient({ apiVersion: '2012-08-10' });
let argon2 = null;
try { argon2 = require('argon2'); } catch (_) { /* optional */ }
const crypto = require('crypto');

const USERS_TABLE = process.env.USERS_TABLE || 'Users';
const EMAIL_INDEX = process.env.EMAIL_INDEX || 'EmailIndex';

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'POST,OPTIONS' },
    body: JSON.stringify(body)
  };
}

function normalizeEmail(email) {
  return String(email || '').trim().toLowerCase();
}

async function hashPassword(password) {
  const pwd = String(password || '');
  if (!pwd) throw new Error('EMPTY_PASSWORD');
  if (argon2 && argon2.hash) {
    // Use argon2id with reasonable defaults
    return await argon2.hash(pwd, { type: argon2.argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 });
  }
  // Fallback: scrypt with strong params
  const salt = crypto.randomBytes(16);
  const key = await new Promise((resolve, reject) => {
    crypto.scrypt(pwd, salt, 64, { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }, (err, derivedKey) => {
      if (err) reject(err); else resolve(derivedKey);
    });
  });
  return `scrypt$${salt.toString('hex')}$${key.toString('hex')}`;
}

exports.handler = async (event) => {
  try {
    if (event.httpMethod === 'OPTIONS') return json(200, { ok: true });
    let body = {};
    try { body = typeof event.body === 'string' ? JSON.parse(event.body) : (event.body || {}); } catch (_) { return json(400, { error: 'INVALID_JSON' }); }
    const businessName = String(body.businessName || '').trim();
    const emailNormalized = normalizeEmail(body.email);
    const password = body.password || '';

    if (!businessName || !emailNormalized || !password) return json(400, { error: 'MISSING_FIELDS' });

    // Check existing by EmailIndex
    const existing = await ddb.query({
      TableName: USERS_TABLE,
      IndexName: EMAIL_INDEX,
      KeyConditionExpression: 'EmailNormalized = :e',
      ExpressionAttributeValues: { ':e': emailNormalized },
      Limit: 1
    }).promise();
    if (existing && existing.Count > 0) return json(409, { error: 'User already exists.' });

    const passwordHash = await hashPassword(password);
    const userId = crypto.randomUUID();
    const nowIso = new Date().toISOString();

    await ddb.put({
      TableName: USERS_TABLE,
      Item: {
        UserId: userId,
        EmailNormalized: emailNormalized,
        PasswordHash: passwordHash,
        BusinessName: businessName,
        IsVerified: false,
        CreatedAt: nowIso
      },
      ConditionExpression: 'attribute_not_exists(UserId)'
    }).promise();

    return json(201, { ok: true, userId });
  } catch (e) {
    console.error('registerUser error', e && (e.stack || e.message || e));
    return json(500, { error: 'SERVER_ERROR' });
  }
};
